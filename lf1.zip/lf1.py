from datetime import date, datetime
import logging
import os
import time
import pytz

logger = logging.getLogger()


def validate_slots(slots):
    if slots["Location"] and slots["Location"]["value"]["originalValue"].lower() not in [
        "new york",
        "ny",
        "log angeles",
        "chicago",
    ]:
        return False, "Location"
    if slots["Cuisine"] and slots["Cuisine"]["value"]["originalValue"].lower() not in [
        "taiwanese",
        "chinese",
        "italian",
        "mexican",
        "japanese",
        "indian",
    ]:
        return False, "Cuisine"
    if slots["Date"] and datetime.strptime(slots["Date"]["value"]["interpretedValue"], "%Y-%m-%d").date() < date.today():
        print("Date selected:", datetime.strptime(slots["Date"]["value"]["interpretedValue"], "%Y-%m-%d").date())
        print("Date today:", date.today())
        return False, "Date"
    if slots["Time"]:
        print("Time selected:", datetime.strptime(slots["Time"]["value"]["interpretedValue"], "%H:%M").time())

    if (
        slots["Date"]
        and slots["Time"]
        and datetime.strptime(slots["Date"]["value"]["interpretedValue"], "%Y-%m-%d").date() == date.today()
        and datetime.strptime(slots["Time"]["value"]["interpretedValue"], "%H:%M").time()
        <= datetime.now(pytz.timezone("America/New_York")).time()
    ):
        return False, "Time"

    return True, None


def delegate(event):
    return {
        "sessionState": {
            # "sessionAttributes": event["sessionState"]["sessionAttributes"],
            "dialogAction": {
                "type": "Delegate",
            },
            "intent": event["sessionState"]["intent"],
        }
    }


def elicit_slot(event, slot_to_elicit):
    return {
        "sessionState": {
            "dialogAction": {
                "type": "ElicitSlot",
                "slotToElicit": slot_to_elicit,
            },
            "intent": event["sessionState"]["intent"],
        }
    }


def lambda_handler(event, context):
    # os.environ["TZ"] = "America/New_York"
    # time.tzset()
    print("event")
    print(event)
    event["slots"] = event["interpretations"][0]["intent"]["slots"]
    print("event.slots")
    print(event["slots"])
    if event["invocationSource"] == "DialogCodeHook":
        is_valid, invalid_slot = validate_slots(event["slots"])
        if not is_valid:
            return elicit_slot(event, invalid_slot)
    elif event["invocationSource"] == "FulfillmentCodeHook":
        print("FulfillmentCodeHook")
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close",
                    # "fulfillmentState": "Fulfilled",
                    # "message": {
                    #     "contentType": "PlainText",
                    #     "content": "Thanks, everything looks good! Have a nice day.",
                    # },
                },
                "intent": {
                    "state": "Fulfilled",
                },
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "Thanks, everything looks good! I'll be texting you the restaurant suggestions to your number shortly. Have a nice day.",
                }
            ],
        }
    return delegate(event)
