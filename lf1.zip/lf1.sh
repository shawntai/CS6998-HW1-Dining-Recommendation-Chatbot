zip lf1.zip lf1.py
aws lambda update-function-code --function-name LF1 --zip-file fileb://lf1.zip